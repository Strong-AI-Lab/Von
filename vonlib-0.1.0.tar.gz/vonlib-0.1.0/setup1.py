from setuptools import find_packages, setup

setup(
    name='vonlib',
    packages=find_packages(include=['vonlib']),
    version='0.1.0',
    description='Python Package of tell_von',
    author='YUchen SU',
)